import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-classes',
  templateUrl: './add-classes.component.html',
  styleUrls: ['./add-classes.component.css']
})
export class AddClassesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
