import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators,FormArray } from '@angular/forms';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-add-test',
  templateUrl: './add-test.component.html',
  styleUrls: ['./add-test.component.css']
})
export class AddTestComponent implements OnInit {
  showModal:boolean=false;
  showTestDetailModal: boolean = false;
  showTestQuestionModal: boolean = false;
  quizForm:FormGroup;
  questionForm: FormGroup;
  totalQuestion: number = 0;
  allQuestion:number[] = [];
  fields: any;
  arr:any[]=[];
  quizId:number =0;
  allClass:any[] = [];
  allSubject:any[] = [];
  totalQuestions:any[] = [];
  timeDurations:any[] = [];
  constructor(private fb: FormBuilder, private quizService: QuizService) { 
    this.quizForm = this.fb.group({
      quizId: ['', Validators.required],
      className: ['', Validators.required],
      subjectName: ['', Validators.required],
      quizTitle: ['', Validators.required],
      totalQuestion: ['', Validators.required],
      timeDuration: ['', Validators.required],
      quizStartTime: ['', Validators.required],
      quizStatus: ['', Validators.required],
    })

    this.questionForm = this.fb.group({
      type: this.fb.group({
        option: this.fb.array([])
      }),
    })
  }

  ngOnInit(): void {
    this.getAllClasses();
    this.getAllSubjects();
    this.getTotalQuestions();
    this.getTimeDurations();
    
  }
  showModalPopup(){
    this.showModal = true;
    this.showTestDetailModal = true;
  }

  quizSubmit() {
    if (this.quizForm.valid) {
      this.quizService.addQuizDetail(this.quizForm.value).subscribe(res => {
        if (res) {
          // this.showModal = true;
          this.showTestDetailModal = false;
          this.showTestQuestionModal = true;

          this.totalQuestion=this.quizForm.value.totalQuestion;
          this.quizId=this.quizForm.value.quizId;
          for(var i=0;i<this.totalQuestion;i++){
           this.allQuestion.push(i+1);
          }
          for(var i=0;i<this.allQuestion.length;i++){
            this.fields = {questionText:"questionText",option1:"option1",option2:"option2",option3:"option3",option4:"option4",ansId:"ansId"};
            this.arr.push(this.fields);
          }

          this.patch();
        }
      });
    }
  }
   questionSubmit() {
    this.showModal = false;
      this.quizService.addQuestionDetail(this.questionForm.value,this.quizId).subscribe(res => {
        if(res){
          this.showTestDetailModal = false;
          this.showTestQuestionModal = false;
          
        }
      });
    
  }

  patch() {
    const control = <FormArray>this.questionForm.get('type.option'); 
    this.arr.forEach(x => {
      control.push(this.patchValues(x.questionText,x.option1,x.option2,x.option2,x.option4,x.ansId))
      this.questionForm.reset();
    })
  }

  patchValues(questionText:any,option1:any,option2:any,option3:any,option4:any,ansId:any) {
    return this.fb.group({
      questionText:[questionText],
      option1:[option1],
      option2:[option2],
      option3:[option3],
      option4:[option4],
      ansId:[ansId],
    })
  }


getAllClasses(){
  this.allClass = 
  [
    {class:1},{class:2},{class:3},{class:4},{class:5},{class:6},{class:7},{class:8},{class:9},{class:10},{class:11},{class:12},
  ]
}

getAllSubjects(){
  this.allSubject = 
  [
    {subject:'Hindi'},{subject:'English'},{subject:'Sanskrit'},{subject:'Maths'},{subject:'Science'},{subject:'Social Science'},{subject:'Physics'},{subject:'Chemistry'},{subject:'Biology'}
  ]
}

getTotalQuestions(){
  this.totalQuestions = 
  [
    {questions:1},{questions:2},{questions:5},{questions:10},{questions:25},{questions:50},
  ]
}

getTimeDurations(){
  this.timeDurations = 
  [
    {duration:1},{duration:2},{duration:5},{duration:10},{duration:15},{duration:30},{duration:60},{duration:120}
  ]
}

}

