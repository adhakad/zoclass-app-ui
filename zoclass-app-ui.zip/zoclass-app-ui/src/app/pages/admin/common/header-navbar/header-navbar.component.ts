import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-navbar',
  templateUrl: './header-navbar.component.html',
  styleUrls: ['./header-navbar.component.css']
})
export class HeaderNavbarComponent implements OnInit {

  abc:boolean = false;
  constructor() {}

  ngOnInit(): void {
  }

  abcd(a:boolean){
    if(a==true){
      this.abc = true;
    }else if(a==false){
      this.abc = false;
    }
    
  }

}
