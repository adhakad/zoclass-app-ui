import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.css']
})
export class NoticeComponent implements OnInit {

  notifications:any[]=[];

  constructor() { }

  ngOnInit(): void {
    this.notification();
  }


  notification(){
    this.notifications = [{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' }]
  }

}
