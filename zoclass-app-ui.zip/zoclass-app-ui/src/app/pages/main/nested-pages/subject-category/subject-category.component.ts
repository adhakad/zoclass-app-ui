import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subject-category',
  templateUrl: './subject-category.component.html',
  styleUrls: ['./subject-category.component.css']
})
export class SubjectCategoryComponent implements OnInit {
  categorys:any[] = [];
  constructor() { }

  ngOnInit(): void {
    this.getCategory();
  }

  getCategory(){
    this.categorys = 
    [
      {title:'Study Material',subtitle:'All biology study material blogs',img:'../../../../../assets/icons8-quiz-66.png',url:'/study-units'},
      {title:'Notes Pdf',subtitle:'All biology topics notes',img:'../../../../../assets/icons8-assessment-64.png',url:'/notes-units'},
      {title:'Test Results',subtitle:'All test performance for biology',img:'../../../../../assets/icons8-quiz-66.png',url:'/test-list'},
      {title:'Ncert Book',subtitle:'All biology study material blogs',img:'../../../../../assets/icons8-quiz-66.png',url:'/test-list'},
    ]
  }

}
