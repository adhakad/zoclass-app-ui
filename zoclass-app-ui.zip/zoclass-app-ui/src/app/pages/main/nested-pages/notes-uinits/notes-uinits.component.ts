import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notes-uinits',
  templateUrl: './notes-uinits.component.html',
  styleUrls: ['./notes-uinits.component.css']
})
export class NotesUinitsComponent implements OnInit {
  notesUnits:any[] = [];
  constructor() { }

  ngOnInit(): void {
    this.getNotesUnits();
  }

  getNotesUnits(){
    this.notesUnits = 
    [
      {unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},
      {unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'}
    ]
  }

}
