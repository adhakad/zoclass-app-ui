import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-study-uinits',
  templateUrl: './study-uinits.component.html',
  styleUrls: ['./study-uinits.component.css']
})
export class StudyUinitsComponent implements OnInit {
  studyUnits:any[] = [];
  constructor() { }

  ngOnInit(): void {
    this.getStudyUnits();
  }

  getStudyUnits(){
    this.studyUnits = 
    [
      {unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},
      {unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'},{unitName:'abc'}
    ]
  }
}
