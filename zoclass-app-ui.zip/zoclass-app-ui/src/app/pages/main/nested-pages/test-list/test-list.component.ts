import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-list',
  templateUrl: './test-list.component.html',
  styleUrls: ['./test-list.component.css']
})
export class TestListComponent implements OnInit {

  testLists:any[]=[];

  constructor() { }

  ngOnInit(): void {
    this.testList();
  }


  testList(){
    this.testLists = [{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' },{ title:'School Exam Date',header:'I m visible because I am open' }]
  }

}
