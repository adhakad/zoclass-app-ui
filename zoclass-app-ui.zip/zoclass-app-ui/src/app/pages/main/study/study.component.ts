import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
declare var jQuery: any;
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-study',
  templateUrl: './study.component.html',
  styleUrls: ['./study.component.css']
})
export class StudyComponent implements OnInit {
  private isBrowser: boolean = isPlatformBrowser(this.platformId);
  subjects: any[] = [];
  blogDetails:any[] = [];
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  
  async ngOnInit() {
    this.getSubjects();
    this.getBlogDetails();
  }

  ngAfterViewInit() {
    if (this.isBrowser) {
      setTimeout(function () {
        jQuery('.subject-carousel').owlCarousel({
          stagePadding:25,
			    items: 2,
			    loop: false,
          dots:false,
			    // margin: 8,
          nav: false,
          responsiveClass: true,
          responsive:{
            1000:{
              items: 3,
            },
          }
        });
      }, 2000);
    }
  }

  getSubjects() {
    this.subjects = [
      {subject:"social science"},{subject:"Mathematics"},{subject:"Chemistry"},{subject:"Physics"},{subject:"Hindi"},{subject:"English"},
    ]
  }

  getBlogDetails(){
    this.blogDetails = [{subject:'Hindi',title:'भारत में नदियों का महत्त्व',author:'25 Sep, 2022 | शालिनी बाजपेयी',description:'प्राचीन काल से ही नदियाँ माँ की तरह हमारा भरण-पोषण करती आ रही हैं। नदियों की वजह से सभ्यताएँ पनपती हैं, बस्तियाँ बसती हैं और कहानियाँ बनती हैं।'},{subject:'English',title:'भारत में नदियों का महत्त्व',author:'25 Sep, 2022 | शालिनी बाजपेयी',description:'प्राचीन काल से ही नदियाँ माँ की तरह हमारा भरण-पोषण करती आ रही हैं। नदियों की वजह से सभ्यताएँ पनपती हैं, बस्तियाँ बसती हैं और कहानियाँ बनती हैं।'},{subject:'Sanskrit',title:'भारत में नदियों का महत्त्व',author:'25 Sep, 2022 | शालिनी बाजपेयी',description:'प्राचीन काल से ही नदियाँ माँ की तरह हमारा भरण-पोषण करती आ रही हैं। नदियों की वजह से सभ्यताएँ पनपती हैं, बस्तियाँ बसती हैं और कहानियाँ बनती हैं।'},{subject:'Maths',title:'भारत में नदियों का महत्त्व',author:'25 Sep, 2022 | शालिनी बाजपेयी',description:'प्राचीन काल से ही नदियाँ माँ की तरह हमारा भरण-पोषण करती आ रही हैं। नदियों की वजह से सभ्यताएँ पनपती हैं, बस्तियाँ बसती हैं और कहानियाँ बनती हैं।'},{subject:'Science',title:'भारत में नदियों का महत्त्व',author:'25 Sep, 2022 | शालिनी बाजपेयी',description:'प्राचीन काल से ही नदियाँ माँ की तरह हमारा भरण-पोषण करती आ रही हैं। नदियों की वजह से सभ्यताएँ पनपती हैं, बस्तियाँ बसती हैं और कहानियाँ बनती हैं।'}]
  }

}
