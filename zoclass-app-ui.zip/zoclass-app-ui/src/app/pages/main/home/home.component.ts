import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
declare var jQuery: any;
import { isPlatformBrowser } from '@angular/common';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private isBrowser: boolean = isPlatformBrowser(this.platformId);
  subject: any[] = [];
  teacher: any[] = [];
  topper:  any[] = [];
  product: any[] = [];
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  async ngOnInit() {
    this.getSubjects();
    this.getTeachers();
    this.getProducts();
    this.getToppers();
  }

  ngAfterViewInit() {
    if (this.isBrowser) {
      setTimeout(function () {
        jQuery('.banner-carousel').owlCarousel({
			    items: 1,
          autoplay: true,
			    autoplayTimeout: 5000,
			    autoplayHoverPause: false,
			    loop: true,
          dots:false,
			    margin: 0,
          nav: false,
          responsiveClass: true,
        });
        jQuery('.subject-carousel').owlCarousel({
          stagePadding:5,
          items: 3,
          loop: false,
          dots:false,
          nav: false,
          responsiveClass: true,
          responsive:{
            0:{
              stagePadding:10,
              items: 3,
            },
            600:{
              stagePadding:10,
              items: 3,
            },
            1000:{
              stagePadding:30,
              items: 4,
            },
          }
        });
      jQuery('.teacher-carousel').owlCarousel({
        stagePadding:20,
        items: 1,
        loop: false,
        dots:false,
        nav: false,
        responsiveClass: true,
        responsive:{
          1000:{
            stagePadding:65,
            items: 3,
          },
        }
      });
      jQuery('.ads-carousel').owlCarousel({
        stagePadding:25,
        items: 1,
        margin:10,
        loop: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        dots:false,
        nav: false,
        responsiveClass: true,
        responsive:{
          1000:{
            stagePadding:65,
            items: 3,
            margin: 40,
          },
        }
      });
      jQuery('.topper-carousel').owlCarousel({
        stagePadding:30,
        items: 2,
        loop: false,
        dots:false,
        nav: false,
        responsiveClass: true,
        responsive:{
          1000:{
            stagePadding:45,
            items: 5,
          },
        }
      });
      jQuery('.product-carousel').owlCarousel({
        stagePadding:15,
        items: 1,
        loop: false,
        dots:false,
        nav: false,
        responsiveClass: true,
        responsive:{
          1000:{
            stagePadding:25,
            items: 3,
          },
        }
      });
      }, 2000);
    }
  }

  getSubjects() {
    this.subject = [
      {subject:"Biology",img:"/assets/icons8-biotech-96.png"},{subject:"Mathematics",img:"/assets/icons8-drafting-compass-96.png"},{subject:"Chemistry",img:"/assets/icons8-chemistry-97.png"},{subject:"Physics",img:"/assets/icons8-atom.png"},{subject:"Hindi",img:"/assets/icons8-drafting-compass-96.png"},{subject:"English",img:"/assets/icons8-atom-64.png"},
    ]
  }

  getTeachers() {
    this.teacher = [
      {teacher:"a"},{teacher:"b"},{teacher:"c"},{teacher:"d"},{teacher:"e"},{teacher:"f"},
    ]
  }

  getToppers(){
    this.topper = [
      {topper:"abhishek dhakad",class:12,persentile:95},{topper:"sonu dhakad",class:12,persentile:90},{topper:"rajiv dhakad",class:10,persentile:91},{topper:"jyoti dhakad",class:12,persentile:95},{topper:"sagar dhakad",class:12,persentile:93},{topper:"abhishek dhakad",class:12,persentile:95},{topper:"anuradha dhakad",class:12,persentile:95},{topper:"abhishek dhakad",class:12,persentile:95},
    ]
  }

  getProducts() {
    this.product = [
      {product:"a"},{product:"b"},{product:"c"},{product:"d"},{product:"e"},{product:"f"},
    ]
  }

}
