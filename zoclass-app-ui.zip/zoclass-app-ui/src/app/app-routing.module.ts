import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/main/home/home.component';
import { TestComponent } from './pages/main/test/test.component';
import { StudyComponent } from './pages/main/study/study.component';
import { NoticeComponent } from './pages/main/notice/notice.component';

import { TestStartComponent } from './pages/main/nested-pages/test-start/test-start.component';
import { AddTestComponent } from './pages/admin/add-test/add-test.component';
import { SubjectCategoryComponent } from './pages/main/nested-pages/subject-category/subject-category.component';
import { StudyUinitsComponent } from './pages/main/nested-pages/study-uinits/study-uinits.component';
import { NotesUinitsComponent } from './pages/main/nested-pages/notes-uinits/notes-uinits.component';
import { BlogListComponent } from './pages/main/nested-pages/blog-list/blog-list.component';
import { SingleBlogComponent } from './pages/main/nested-pages/single-blog/single-blog.component';
import { TestListComponent } from './pages/main/nested-pages/test-list/test-list.component';
import { TestResultComponent } from './pages/main/nested-pages/test-result/test-result.component';
import { AbcComponent } from './pages/admin/abc/abc.component';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'test',component:TestComponent},
  { path: 'study', component: StudyComponent },
  { path: 'notice', component: NoticeComponent },

  { path:'subject-category', component:SubjectCategoryComponent},
  { path:'study-units', component:StudyUinitsComponent},
  { path:'notes-units', component:NotesUinitsComponent},
  { path:'blog-list', component:BlogListComponent},
  { path:'single-blog', component:SingleBlogComponent},
  { path:'test-start', component:TestStartComponent},
  { path:'test-list', component:TestListComponent},
  { path:'test-result', component:TestResultComponent},


  // Admin Routing Section
  { path:'dashboard',component:DashboardComponent},
  { path:'add-test', component:AddTestComponent},
  { path:'abc', component:AbcComponent}



  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
