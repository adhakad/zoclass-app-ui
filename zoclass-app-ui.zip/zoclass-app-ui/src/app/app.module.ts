import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PortalModule } from '@angular/cdk/portal';
// import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule } from '@angular/forms';
import { MaterialUiModule } from './material/material-ui/material-ui.module';
import { HttpClientModule } from '@angular/common/http';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { RoundProgressModule } from 'angular-svg-round-progressbar';
import { MatMomentDatetimeModule } from '@mat-datetimepicker/moment';
import { MatDatetimepickerModule, MAT_DATETIME_FORMATS } from '@mat-datetimepicker/core';

import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { HomeComponent } from './pages/main/home/home.component';
import { TestComponent } from './pages/main/test/test.component';
import { StudyComponent } from './pages/main/study/study.component';
import { NoticeComponent } from './pages/main/notice/notice.component';


import { TestStartComponent } from './pages/main/nested-pages/test-start/test-start.component';
import { AddTestComponent } from './pages/admin/add-test/add-test.component';
import { SubjectCategoryComponent } from './pages/main/nested-pages/subject-category/subject-category.component';
import { StudyUinitsComponent } from './pages/main/nested-pages/study-uinits/study-uinits.component';
import { NotesUinitsComponent } from './pages/main/nested-pages/notes-uinits/notes-uinits.component';
import { BlogListComponent } from './pages/main/nested-pages/blog-list/blog-list.component';
import { SingleBlogComponent } from './pages/main/nested-pages/single-blog/single-blog.component';
import { TestListComponent } from './pages/main/nested-pages/test-list/test-list.component';
import { TestResultComponent } from './pages/main/nested-pages/test-result/test-result.component';
import { AddClassesComponent } from './pages/teacher/add-classes/add-classes.component';
import { AbcComponent } from './pages/admin/abc/abc.component';
import { HeaderNavbarComponent } from './pages/admin/common/header-navbar/header-navbar.component';
import { SideNavbarComponent } from './pages/admin/common/side-navbar/side-navbar.component';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { NavbarComponent } from './common/navbar/navbar.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    TestComponent,
    StudyComponent,
    NoticeComponent,
    
    TestStartComponent,
         AddTestComponent,
         SubjectCategoryComponent,
         StudyUinitsComponent,
         NotesUinitsComponent,
         BlogListComponent,
         SingleBlogComponent,
         TestListComponent,
         TestResultComponent,
         AddClassesComponent,
         AbcComponent,
         HeaderNavbarComponent,
         DashboardComponent,
         NavbarComponent,
         SideNavbarComponent,
         
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgxSkeletonLoaderModule,
    RoundProgressModule,

    PortalModule,
    MaterialUiModule,
    MatMomentDatetimeModule,
    MatDatetimepickerModule,
  ],
  providers: [
    {
      provide: MAT_DATETIME_FORMATS,
      useValue: {
        parse: {
          dateInput: 'L',
          monthInput: 'MMMM',
          timeInput: 'LT',
          datetimeInput: 'L LT',
        },
        display: {
          dateInput: 'L',
          monthInput: 'MMMM',
          datetimeInput: 'L LT',
          timeInput: 'LT',
          monthYearLabel: 'MMM YYYY',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM YYYY',
          popupHeaderDateLabel: 'ddd, DD MMM',
        },
      },
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
