const express = require('express');
const router = express.Router();
const quizDetailModel = require('../models/quizDetail');

// **************************Quiz Detail section
router.get('/get-quiz-detail', async (req, res, next) => {
    try {
      const quizDetail = await quizDetailModel.find({quizId:100});
      const quizStartTime = quizDetail[0].quizStartTime;
      const quizEndTime = quizDetail[0].quizEndTime;
      const now = new Date();
      function toTimestamp(strDate){
        var datum = Date.parse(strDate);
        return datum/1000;
      }
      const timesTamp = toTimestamp(now)
      const tt = 60 * quizDetail[0].timeDuration;
      const duration = quizStartTime - timesTamp;
      const t = -1*duration;
      
      res.json({ quizDetail: quizDetail,timesTamp:timesTamp,tt:tt,t:t });
    } catch (error) {
      console.log(error);
    }
  });
  router.post('/add-quiz-detail', async (req, res, next) => {
    var quizId = req.body.quizId;
    var className = req.body.className;
    var subjectName = req.body.subjectName;
    var quizTitle = req.body.quizTitle;
    var totalQuestion = req.body.totalQuestion;
    var timeDuration = req.body.timeDuration;
    var quizStartTime = req.body.quizStartTime; 
    var quizEndTime = req.body.quizEndTime;
    function toTimestamp(strDate){
      var datum = Date.parse(strDate);
      return datum/1000;
    }
    quizStartTime = toTimestamp(quizStartTime);
    quizEndTime = (60*timeDuration) + quizStartTime;

    try {
      const addQuiz = {
        quizId: quizId,
        className: className,
        subjectName: subjectName,
        quizTitle: quizTitle,
        totalQuestion: totalQuestion,
        timeDuration: timeDuration,
        quizStartTime: quizStartTime,
        quizEndTime:quizEndTime,
        quizStatus: req.body.quizStatus,
      }
      const quizDetail = await quizDetailModel.create(addQuiz);
      res.json(quizDetail);
    } catch (error) {
      console.log(error);
    }
  });

  module.exports = router;